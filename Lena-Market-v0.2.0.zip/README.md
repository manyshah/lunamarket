# Lena Market — Portfolio Edition

A premium RTL beauty e-commerce frontend portfolio built with React, TypeScript and Vite.

## Highlights

- Premium responsive RTL storefront
- Rounded hero slider with 10-second autoplay and smooth horizontal transitions
- Touch swipe on mobile and manual navigation controls
- Live product search
- Product catalog, category filters and sorting
- Product detail pages
- Wishlist persistence with `localStorage`
- Cart with quantity controls and demo coupon (`LENA10`)
- Multi-step demo checkout
- Demo phone authentication and OTP (`12345`)
- User profile and demo order history
- Visual order tracking (`LN-140500`)
- Responsive mobile navigation
- GitHub Pages deployment workflow
- HashRouter routing for reliable static hosting

## Tech stack

- React
- TypeScript
- Vite
- React Router
- Lucide React
- Handcrafted responsive CSS

## Development

```bash
npm install
npm run dev
```

## Validation and production build

```bash
npm run typecheck
npm run build
npm run preview
```

## GitHub Pages

The included workflow validates the repository structure before building. The `src` and `public` directories must be committed to the repository.

After deployment, this repository is intended to be available at:

`https://manyshah.github.io/lunamarket/`

## Demo credentials

- OTP: `12345`
- Coupon: `LENA10`
- Tracking code: `LN-140500`

## Notes

This is a portfolio frontend demo. Payment, SMS, inventory, shipping and account operations are simulated and are not connected to production services.


## Build compatibility

- GitHub Pages workflow included
- Vite CSS type declarations included for TypeScript builds
- Static asset paths are compatible with repository Pages hosting

## Font note

The UI is configured globally for `IRANSans` / `IRANSansWeb` / `IRANSansX`. The licensed binary font files are not bundled in this repository; when the font is unavailable on the viewer device, the CSS falls back to Persian-safe system fonts.
