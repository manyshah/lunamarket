# راهنمای آپلود Lena Market روی GitHub

## نکته مهم
نسخه قبلی روی GitHub ناقص آپلود شده بود و پوشه‌های `src` و `public` در Repository وجود نداشتند. این نسخه کامل است.

## روش صحیح جایگزینی
1. فایل ZIP را Extract کن.
2. داخل پوشه Extract شده باید مستقیماً این موارد را ببینی:
   - `.github`
   - `public`
   - `src`
   - `index.html`
   - `package.json`
   - `vite.config.ts`
   - فایل‌های `tsconfig`
3. محتویات همین پوشه را در ریشه Repository `manyshah/lunamarket` قرار بده.
4. حتماً بررسی کن در GitHub این مسیر باز شود:
   - `src/main.tsx`
   - `src/App.tsx`
   - `public/lena-logo.webp`
5. در `Settings > Pages` مقدار Source روی `GitHub Actions` باشد.
6. Commit/Push باعث اجرای Workflow می‌شود. اجرای دستی هم از تب Actions امکان‌پذیر است.

## آدرس سایت
پس از سبز شدن Deploy:

`https://manyshah.github.io/lunamarket/`

## اطلاعات Demo
- OTP: `12345`
- Coupon: `LENA10`
- Tracking: `LN-140500`
