# Changelog

## 0.2.0

- Standardized the visible brand as Lena Market across the storefront.
- Replaced the previous logo with the new transparent Lena Market logo.
- Rebuilt the home hero as a four-image responsive carousel with 10-second autoplay, smooth transition, swipe/drag and navigation controls.
- Set the Manee Gluta Collagen Pink campaign as the first slide.
- Added responsive layout overrides for phone, tablet, laptop and desktop widths.
- Configured the entire interface to prefer the IRANSans font family, with safe Persian fallbacks.
- Optimized slider images to WebP for faster static hosting.

## 0.1.2

- Fixed TypeScript build failure caused by unsupported `Instagram` export from `lucide-react`.
- Added Vite/CSS module type declarations for the global stylesheet import.
- Updated GitHub Actions structure verification to require `src/vite-env.d.ts`.
