import { ChevronLeft, ChevronRight } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'

const slides = [
  {
    src: './slides/01-gluta-collagen.webp',
    alt: 'پودر گلوتا کلاژن صورتی مانی در لنا مارکت',
    link: '/products?category=مکمل',
    label: 'مشاهده مکمل‌های زیبایی',
  },
  {
    src: './slides/02-skincare.webp',
    alt: 'محصولات مراقبت پوست لنا مارکت',
    link: '/products?category=پوست',
    label: 'مشاهده محصولات مراقبت پوست',
  },
  {
    src: './slides/03-cosmetics.webp',
    alt: 'محصولات آرایشی ویژه لنا مارکت',
    link: '/products?category=آرایشی',
    label: 'مشاهده محصولات آرایشی',
  },
  {
    src: './slides/04-beauty-care.webp',
    alt: 'محصولات زیبایی و مراقبتی لنا مارکت',
    link: '/products',
    label: 'مشاهده همه محصولات',
  },
]

export function HeroSlider() {
  const [active, setActive] = useState(0)
  const [paused, setPaused] = useState(false)
  const pointerStart = useRef<number | null>(null)
  const dragged = useRef(false)

  useEffect(() => {
    if (paused) return
    const timer = window.setInterval(
      () => setActive(current => (current + 1) % slides.length),
      10000,
    )
    return () => window.clearInterval(timer)
  }, [paused])

  const go = (index: number) => setActive((index + slides.length) % slides.length)

  const onPointerDown = (event: React.PointerEvent<HTMLElement>) => {
    pointerStart.current = event.clientX
    dragged.current = false
  }

  const onPointerUp = (event: React.PointerEvent<HTMLElement>) => {
    if (pointerStart.current === null) return
    const delta = event.clientX - pointerStart.current
    if (Math.abs(delta) > 45) {
      dragged.current = true
      go(delta > 0 ? active - 1 : active + 1)
    }
    pointerStart.current = null
  }

  const blockClickAfterDrag = (event: React.MouseEvent<HTMLElement>) => {
    if (!dragged.current) return
    event.preventDefault()
    event.stopPropagation()
    dragged.current = false
  }

  return (
    <section
      className="hero-shell"
      aria-roledescription="carousel"
      aria-label="پیشنهادهای ویژه لنا مارکت"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onPointerDown={onPointerDown}
      onPointerUp={onPointerUp}
      onPointerCancel={() => { pointerStart.current = null }}
      onClickCapture={blockClickAfterDrag}
    >
      <div
        className="hero-slider"
        style={{ transform: `translate3d(-${active * 100}%, 0, 0)` }}
      >
        {slides.map((slide, index) => (
          <article className="hero-slide" key={slide.src} aria-hidden={active !== index}>
            <Link className="hero-banner-link" to={slide.link} aria-label={slide.label} tabIndex={active === index ? 0 : -1}>
              <img
                className="hero-banner-image"
                src={slide.src}
                alt={slide.alt}
                width="1600"
                height="900"
                loading={index === 0 ? 'eager' : 'lazy'}
                fetchPriority={index === 0 ? 'high' : 'auto'}
                draggable={false}
              />
            </Link>
          </article>
        ))}
      </div>

      <button className="hero-arrow hero-arrow--right" onClick={() => go(active - 1)} aria-label="اسلاید قبلی">
        <ChevronRight />
      </button>
      <button className="hero-arrow hero-arrow--left" onClick={() => go(active + 1)} aria-label="اسلاید بعدی">
        <ChevronLeft />
      </button>

      <div className="hero-dots" aria-label="انتخاب اسلاید">
        {slides.map((_, index) => (
          <button
            key={index}
            className={active === index ? 'is-active' : ''}
            onClick={() => go(index)}
            aria-label={`اسلاید ${index + 1}`}
            aria-current={active === index ? 'true' : undefined}
          >
            <span className={active === index && !paused ? 'dot-progress' : ''} />
          </button>
        ))}
      </div>
    </section>
  )
}
